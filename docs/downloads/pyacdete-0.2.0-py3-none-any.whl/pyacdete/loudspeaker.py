"""Loudspeaker frequency response, harmonic distortion and delay measurements."""
import csv
from pathlib import Path
import warnings

import matplotlib.pyplot as plt
import numpy as np
from scipy import signal

__all__ = ["h1_response", "single_tone_thd", "estimate_delay"]


def h1_response(x, y, fs, *, mode="both", threshold=0.9,
                nperseg=None, save_path="response.csv"):
    """Estimate H1 magnitude/phase from synchronized reference x and output y.

    mode: "magnitude", "phase", or "both".
    threshold: minimum magnitude-squared coherence for displayed/exported data.
    nperseg: Welch segment length; None chooses a starting value automatically.
    save_path: CSV path, or None to skip saving.

    Uses the original magnitude_response_principle_1.py and
    phase_response_principle_1.py calculation steps, with user-supplied x/y.
    Returns frequency_hz, coherence, valid, nperseg, and the selected
    magnitude_db/phase_deg arrays in a dictionary. Rejected values are NaN
    in arrays, blank in CSV, and gaps in plots. Close the plot to return.
    Magnitude is transfer gain, not dB SPL. Phase retains measurement delay.
    """
    if mode not in ("magnitude", "phase", "both"):
        raise ValueError('mode must be "magnitude", "phase", or "both"')
    if isinstance(fs, (bool, np.bool_)) or not np.isscalar(fs) or not np.isreal(fs) or not np.isfinite(fs) or fs <= 0:
        raise ValueError("fs must be a positive finite sampling frequency")
    if not np.isscalar(threshold) or not np.isreal(threshold) or not np.isfinite(threshold) or not 0 <= threshold <= 1:
        raise ValueError("threshold must be between 0 and 1")
    x, y = np.asarray(x), np.asarray(y)
    if x.ndim != 1 or y.ndim != 1 or x.size != y.size or x.size == 0:
        raise ValueError("x and y must be nonempty, equal-length 1D signals")
    if x.dtype.kind not in "iuf" or y.dtype.kind not in "iuf":
        raise ValueError("x and y must contain real numeric samples")
    x, y = x.astype(float), y.astype(float)
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError("x and y must contain only finite samples")

    # Target <=0.5 seconds, keeping >=8 complete, half-overlapped segments.
    if nperseg is None:
        limit = min(fs / 2, 2 * len(x) / 9)
        if limit < 4:
            raise ValueError("too little data for automatic Welch settings")
        nperseg = 2 ** int(np.floor(np.log2(limit)))
    if isinstance(nperseg, (bool, np.bool_)) or not isinstance(nperseg, (int, np.integer)) or nperseg < 4:
        raise ValueError("nperseg must be an integer >= 4, or None")
    noverlap = nperseg // 2
    if len(x) < nperseg + (nperseg - noverlap):
        raise ValueError("at least two complete Welch segments are required")
    segments = 1 + (len(x) - nperseg) // (nperseg - noverlap)
    if segments < 8:
        warnings.warn("Fewer than 8 Welch segments; coherence may be optimistic.", stacklevel=2)
    settings = dict(fs=float(fs), window="hann", nperseg=nperseg,
                    noverlap=noverlap, nfft=nperseg, detrend="constant")

    # Original demo core; x is the demo's input u.
    # SciPy csd(x, y) uses conj(X)*Y: delayed output has negative phase slope.
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        f, Suu = signal.welch(x, **settings)
        _, Syu = signal.csd(x, y, **settings)
    if not np.all(np.isfinite(Suu)) or not np.all(np.isfinite(Syu)):
        raise ValueError("spectral estimates overflowed; check sample units")
    if Suu.max() <= 0:
        raise ValueError("x has no usable reference energy after detrending")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        H1 = Syu / Suu
    if not np.all(np.isfinite(H1)):
        raise ValueError("H1 is undefined; check for zero reference PSD or numerical overflow")

    # Original demo magnitude, phase, coherence, and masking order.
    magnitude = np.abs(H1)
    magnitude_db = 20 * np.log10(np.maximum(magnitude, 1e-12))
    phi_wrapped = np.angle(H1)
    phi = np.unwrap(phi_wrapped)
    phase_deg = np.degrees(phi)
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        _, C = signal.coherence(x, y, **settings)
    valid = C >= threshold
    result = dict(frequency_hz=f, coherence=C, valid=valid, nperseg=int(nperseg))
    curves = {}
    if mode in ("magnitude", "both"):
        result["magnitude_db"] = np.where(valid, magnitude_db, np.nan)
        curves["magnitude_db"] = "Magnitude (dB re transfer gain 1)"
    if mode in ("phase", "both"):
        result["phase_deg"] = np.where(valid, phase_deg, np.nan)
        curves["phase_deg"] = "Unwrapped phase (degree)"
    if not np.any(valid):
        warnings.warn("No accepted response bins; inspect coherence and input data.", stacklevel=2)

    if save_path is not None:
        columns = ["frequency_hz", "coherence", *curves]
        with Path(save_path).open("w", newline="", encoding="utf-8") as stream:
            writer = csv.writer(stream)
            writer.writerow(columns)
            writer.writerows([float(v) if np.isfinite(v) else "" for v in row]
                             for row in zip(*(result[key] for key in columns)))

    fig, axes = plt.subplots(1 + len(curves), 1, sharex=True,
                              figsize=(10, 3 * (1 + len(curves))))
    axes[0].plot(f, C)
    axes[0].axhline(threshold, color="red", linestyle="--", label=f"Threshold = {threshold}")
    axes[0].set(ylabel="Coherence C", ylim=(0, 1.05), title="H1 response")
    axes[0].legend()
    for ax, (key, label) in zip(axes[1:], curves.items()):
        ax.plot(f, result[key])
        ax.set_ylabel(label)
    for ax in axes:
        ax.grid(True)
    axes[-1].set(xlabel="Frequency (Hz)", xlim=(0, float(fs) / 2))
    fig.tight_layout()
    plt.show()
    return result


def single_tone_thd(mic_samples, fs, f0, max_order=3):
    """Estimate THD and harmonic peak amplitudes from a steady recording.

    The recording must span a whole number of test-tone cycles. Compare
    THD through max_order and 3 * max_order, and warn if the second
    estimate is more than 10 percent higher.

    Return thd_percent and amplitude_peak, ordered from the fundamental
    through the highest harmonic used.
    """
    samples = np.asarray(mic_samples)
    if (samples.ndim != 1 or samples.size == 0 or samples.dtype.kind not in "iuf"
            or not np.all(np.isfinite(samples))):
        raise ValueError("mic_samples must be a nonempty 1D array of finite real samples")
    for name, value in (("fs", fs), ("f0", f0)):
        if (not np.isscalar(value) or np.asarray(value).dtype.kind not in "iuf"
                or not 0 < float(value) < float("inf")):
            raise ValueError(f"{name} must be a positive finite frequency in Hz")
    if not isinstance(max_order, (int, np.integer)) or max_order < 2:
        raise ValueError("max_order must be an integer >= 2")

    sample_count = samples.size
    bin_position = (float(f0) / float(fs)) * sample_count
    if not np.isfinite(bin_position):
        raise ValueError("the test tone must fall on a positive FFT bin")
    fundamental_bin = round(bin_position)
    if fundamental_bin < 1 or abs(bin_position - fundamental_bin) > 1e-8:
        raise ValueError("mic_samples must span a whole number of test-tone cycles")

    max_order = int(max_order)
    extended_order = 3 * max_order
    if 2 * extended_order * fundamental_bin >= sample_count:
        raise ValueError("the FFT does not provide all requested positive harmonic bins")
    harmonic_bins = fundamental_bin * np.arange(1, extended_order + 1)
    spectrum = np.fft.rfft(samples.astype(float, copy=False))
    peak_amplitudes = (2 / sample_count) * np.abs(spectrum[harmonic_bins])
    if not np.all(np.isfinite(peak_amplitudes)):
        raise ValueError("harmonic amplitudes overflowed; check sample units")

    # Discard floating-point residue before comparing the two estimates.
    roundoff = 8 * np.finfo(float).eps * peak_amplitudes.max()
    peak_amplitudes[peak_amplitudes <= roundoff] = 0.0
    if peak_amplitudes[0] == 0:
        raise ValueError("mic_samples has no usable fundamental at f0")

    relative_amplitudes = peak_amplitudes[1:] / peak_amplitudes[0]
    thd_base = float(100 * np.linalg.norm(relative_amplitudes[:max_order - 1]))
    thd_extended = float(100 * np.linalg.norm(relative_amplitudes))
    small, big = sorted((thd_base, thd_extended))
    if big > 1.10 * small:
        warnings.warn(
            f"Higher-order harmonics increase THD from {thd_base:.6g}% to "
            f"{thd_extended:.6g}% and may indicate stronger nonlinear behavior "
            f"under these measurement conditions. Using orders 2 through {extended_order}.",
            RuntimeWarning,
            stacklevel=2,
        )
        return dict(thd_percent=thd_extended, amplitude_peak=peak_amplitudes)
    return dict(thd_percent=thd_base, amplitude_peak=peak_amplitudes[:max_order])


def estimate_delay(x, y, fs):
    """Estimate the integer-sample delay of recording ``y`` relative to ``x``.

    Supply finite, nonconstant, real 1D signals on the same sample clock
    and time origin, with a positive sampling frequency ``fs`` in Hz.
    Each signal is centered by its own mean. The first maximum of the
    full, unnormalized time-domain cross-correlation selects the lag.

    Return ``lag_samples``, ``delay_seconds``, ``lags_samples`` and
    ``correlation`` in a dictionary. A positive lag means ``y`` arrives
    later than ``x``. The two arrays span all lags in increasing order.
    """
    if (not np.isscalar(fs) or np.asarray(fs).dtype.kind not in "iuf"
            or not 0 < float(fs) < np.inf):
        raise ValueError("fs must be a positive finite sampling frequency in Hz")
    reference = _center_delay_signal(x, "x")
    recorded = _center_delay_signal(y, "y")

    with np.errstate(over="ignore", invalid="ignore"):
        correlation = signal.correlate(recorded, reference, mode="full", method="direct")
    if not np.all(np.isfinite(correlation)) or not np.any(correlation):
        raise ValueError("correlation is undefined at this sample scale")
    lags = signal.correlation_lags(recorded.size, reference.size, mode="full")
    lag = int(lags[np.argmax(correlation)])
    return dict(lag_samples=lag, delay_seconds=lag / float(fs),
                lags_samples=lags, correlation=correlation)


def _center_delay_signal(samples, name):
    samples = np.asarray(samples)
    if samples.ndim != 1 or samples.size < 2 or samples.dtype.kind not in "iuf":
        raise ValueError(f"{name} must be a real 1D signal with at least two samples")
    with np.errstate(over="ignore", invalid="ignore"):
        samples = samples.astype(float, copy=False)
        if not np.all(np.isfinite(samples)) or np.all(samples == samples[0]):
            raise ValueError(f"{name} must contain finite, nonconstant samples")
        return samples - samples.mean()
